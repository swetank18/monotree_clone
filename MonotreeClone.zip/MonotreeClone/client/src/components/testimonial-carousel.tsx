import { useState, useEffect } from 'react';

interface Testimonial {
  id: number;
  title: string;
  quote: string;
  company: string;
  industry: string;
  stats: Array<{ label: string; value: string }>;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    title: "Trusted by hospitality teams",
    quote: "Monotree helped create a community across our restaurants. It's great to collaborate with Monotree; it's dynamic, and we brainstorm about features, possibilities, and the industry as a whole. I really like the mix of operational features with communication - that it becomes a social network.",
    company: "Madklubben",
    industry: "Food & Hospitality",
    stats: [
      { label: "Employees", value: "1500+" },
      { label: "Departments", value: "46" }
    ]
  },
  {
    id: 2,
    title: "Streamlined hotel operations",
    quote: "We launched our app in the autumn of 2021 and I honestly cannot understand how we could run our business beforehand. With the app, communication has not only become easier, but it has also been strengthened both within individual hotels and across the company.",
    company: "Hotel Group",
    industry: "Hospitality",
    stats: [
      { label: "Staff", value: "800+" },
      { label: "Locations", value: "12" }
    ]
  },
  {
    id: 3,
    title: "Mobile-first communication",
    quote: "Monotree has been a great tool for internal communication and it works flawlessly on mobile. We are also excited to have a platform where we can gather all handbooks and instructions in one place - where the information is easily accessible for everyone on their phone.",
    company: "Restaurant Chain",
    industry: "Food Service",
    stats: [
      { label: "Team Members", value: "600+" },
      { label: "Restaurants", value: "25" }
    ]
  }
];

export function TestimonialCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % testimonials.length);
  };

  const previousSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  const scrollToDemo = () => {
    const element = document.getElementById('demo');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="testimonials" className="container my-10" data-testid="testimonial-carousel">
      <div 
        className="relative overflow-hidden rounded-[14px] border-glass min-h-[280px]"
        style={{
          background: 'linear-gradient(180deg, rgba(12,20,30,0.6), rgba(6,12,18,0.5))'
        }}
        data-testid="carousel-container"
      >
        <div 
          className="flex transition-transform duration-700 ease-[cubic-bezier(0.2,0.9,0.2,1)]"
          style={{ transform: `translateX(-${currentSlide * 100}%)` }}
          data-testid="carousel-slides"
        >
          {testimonials.map((testimonial) => (
            <article 
              key={testimonial.id}
              className="min-w-full px-8 py-8 flex gap-8 items-center"
              aria-label={`Testimonial ${testimonial.id}`}
              data-testid={`slide-${testimonial.id}`}
            >
              <div className="flex-1" data-testid="slide-content">
                <h3 className="m-0 mb-3 text-2xl font-bold" data-testid="testimonial-title">
                  {testimonial.title}
                </h3>
                <p className="text-muted m-0 mb-5 text-base leading-relaxed" data-testid="testimonial-quote">
                  "{testimonial.quote}"
                </p>
                <button
                  onClick={scrollToDemo}
                  className="bg-transparent border border-white/10 px-3.5 py-2.5 rounded-[10px] font-semibold transition-smooth hover:border-white/20 hover:bg-white/5"
                  data-testid="button-read-case-study"
                >
                  Read case study
                </button>
              </div>
              
              <div className="w-80 hidden lg:flex flex-col gap-4 items-end" data-testid="company-info">
                <div 
                  className="p-5 rounded-xl w-full text-right"
                  style={{ background: 'linear-gradient(130deg, #06202a, #052f3d)' }}
                  data-testid="company-card"
                >
                  <div className="font-extrabold text-xl" data-testid="company-name">
                    {testimonial.company}
                  </div>
                  <div className="text-muted text-sm" data-testid="company-industry">
                    {testimonial.industry}
                  </div>
                  <div className="grid grid-cols-2 gap-3 mt-4" data-testid="company-stats">
                    {testimonial.stats.map((stat, index) => (
                      <div 
                        key={index}
                        className="text-center p-2 rounded-lg"
                        style={{ background: 'rgba(255,255,255,0.05)' }}
                        data-testid={`company-stat-${index}`}
                      >
                        <div className="font-bold text-base" data-testid="stat-value">{stat.value}</div>
                        <div className="text-muted text-xs mt-0.5" data-testid="stat-label">{stat.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
        
        <div 
          className="absolute left-3 right-3 top-1/2 -translate-y-1/2 flex justify-between pointer-events-none"
          data-testid="carousel-controls"
        >
          <button 
            className="pointer-events-auto bg-black/35 border-0 p-2.5 rounded-lg text-white text-lg transition-smooth hover:bg-black/50 cursor-pointer"
            onClick={previousSlide}
            aria-label="Previous slide"
            data-testid="button-previous-slide"
          >
            ‹
          </button>
          <button 
            className="pointer-events-auto bg-black/35 border-0 p-2.5 rounded-lg text-white text-lg transition-smooth hover:bg-black/50 cursor-pointer"
            onClick={nextSlide}
            aria-label="Next slide"
            data-testid="button-next-slide"
          >
            ›
          </button>
        </div>
      </div>
      
      <div className="flex gap-2 justify-center mt-3" data-testid="carousel-dots">
        {testimonials.map((_, index) => (
          <div 
            key={index}
            className={`w-2.5 h-2.5 rounded-full cursor-pointer border transition-smooth hover:bg-white/40 ${
              index === currentSlide ? 'bg-accent' : 'bg-white/20'
            }`}
            style={{ border: '1px solid rgba(255,255,255,0.03)' }}
            onClick={() => goToSlide(index)}
            data-testid={`carousel-dot-${index}`}
          />
        ))}
      </div>
    </section>
  );
}
