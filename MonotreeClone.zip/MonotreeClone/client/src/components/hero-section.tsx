export function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="container py-16 lg:py-20" aria-labelledby="hero-heading" data-testid="hero-section">
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_420px] gap-8 items-stretch">
        {/* Left: Hero text */}
        <div 
          className="bg-gradient-card rounded-[14px] p-8 shadow-card border-glass"
          data-testid="hero-card"
        >
          <span 
            className="inline-block font-bold px-2.5 py-1.5 rounded-full mb-3.5 text-accent"
            style={{ background: 'rgba(255,255,255,0.02)' }}
            data-testid="eyebrow-text"
          >
            Employee Experience
          </span>
          <h1 
            id="hero-heading"
            className="text-[40px] lg:text-[40px] leading-[1.03] m-0 mb-3 font-extrabold"
            data-testid="hero-heading"
          >
            Put people first — fast, user-friendly & engaging
          </h1>
          <p className="text-muted m-0 mb-5 text-lg leading-relaxed" data-testid="hero-description">
            A single mobile-first platform for communication, onboarding, operations, and wellbeing that keeps hourly teams connected and productive.
          </p>

          <div className="flex gap-3 flex-wrap justify-center lg:justify-start" data-testid="hero-cta-buttons">
            <button
              onClick={() => scrollToSection('demo')}
              className="bg-gradient-accent px-4 py-2.5 rounded-[10px] text-[#06202a] font-bold shadow-cta transition-smooth hover:-translate-y-0.5 hover:shadow-cta-hover"
              data-testid="button-book-demo"
            >
              Book a demo
            </button>
            <button
              onClick={() => scrollToSection('product')}
              className="bg-transparent border border-white/10 px-3.5 py-2.5 rounded-[10px] font-semibold transition-smooth hover:border-white/20 hover:bg-white/5"
              data-testid="button-see-features"
            >
              See features
            </button>
            <button
              onClick={() => scrollToSection('testimonials')}
              className="bg-transparent border border-white/10 px-3.5 py-2.5 rounded-[10px] font-semibold transition-smooth hover:border-white/20 hover:bg-white/5"
              data-testid="button-explore-cases"
            >
              Explore cases
            </button>
          </div>

          <div className="flex gap-3 mt-5 items-center flex-wrap justify-center lg:justify-start" data-testid="hero-stats">
            <div className="p-2.5 rounded-[10px] text-center transition-smooth hover:bg-white/10" style={{ background: 'rgba(255,255,255,0.02)' }} data-testid="stat-rating">
              <strong>4.9</strong>
              <div className="text-muted text-[13px]">Avg. rating</div>
            </div>
            <div className="p-2.5 rounded-[10px] text-center transition-smooth hover:bg-white/10" style={{ background: 'rgba(255,255,255,0.02)' }} data-testid="stat-activity">
              <strong>75.2%</strong>
              <div className="text-muted text-[13px]">Daily activity</div>
            </div>
            <div className="p-2.5 rounded-[10px] text-center transition-smooth hover:bg-white/10" style={{ background: 'rgba(255,255,255,0.02)' }} data-testid="stat-opens">
              <strong>4.2</strong>
              <div className="text-muted text-[13px]">Daily opens</div>
            </div>
          </div>
        </div>

        {/* Right: Feature highlights */}
        <div className="grid gap-3" data-testid="feature-list">
          <div 
            className="flex gap-3 items-start p-3 rounded-xl border transition-smooth hover:bg-white/8 hover:border-white/10"
            style={{
              background: 'linear-gradient(180deg, rgba(255,255,255,0.01), transparent)',
              border: '1px solid rgba(255,255,255,0.02)'
            }}
            data-testid="feature-communication"
          >
            <div 
              className="w-[52px] h-[52px] rounded-[10px] grid place-items-center font-bold text-xl"
              style={{ background: 'rgba(255,255,255,0.03)' }}
            >
              💬
            </div>
            <div>
              <div className="font-bold">Communication & Social</div>
              <div className="text-muted text-[13px] mt-1.5">A fully functional social network fosters collaboration and fun in your workplace community.</div>
            </div>
          </div>

          <div 
            className="flex gap-3 items-start p-3 rounded-xl border transition-smooth hover:bg-white/8 hover:border-white/10"
            style={{
              background: 'linear-gradient(180deg, rgba(255,255,255,0.01), transparent)',
              border: '1px solid rgba(255,255,255,0.02)'
            }}
            data-testid="feature-training"
          >
            <div 
              className="w-[52px] h-[52px] rounded-[10px] grid place-items-center font-bold text-xl"
              style={{ background: 'rgba(255,255,255,0.03)' }}
            >
              📚
            </div>
            <div>
              <div className="font-bold">Onboarding, Information & Training</div>
              <div className="text-muted text-[13px] mt-1.5">Efficient, media rich and intuitive development of the people in your organization.</div>
            </div>
          </div>

          <div 
            className="flex gap-3 items-start p-3 rounded-xl border transition-smooth hover:bg-white/8 hover:border-white/10"
            style={{
              background: 'linear-gradient(180deg, rgba(255,255,255,0.01), transparent)',
              border: '1px solid rgba(255,255,255,0.02)'
            }}
            data-testid="feature-wellbeing"
          >
            <div 
              className="w-[52px] h-[52px] rounded-[10px] grid place-items-center font-bold text-xl"
              style={{ background: 'rgba(255,255,255,0.03)' }}
            >
              💚
            </div>
            <div>
              <div className="font-bold">Well-being & Retention</div>
              <div className="text-muted text-[13px] mt-1.5">Give everyone a voice, measure their well-being, and retain your talent.</div>
            </div>
          </div>

          <div 
            className="flex gap-3 items-start p-3 rounded-xl border transition-smooth hover:bg-white/8 hover:border-white/10 mt-auto"
            style={{
              background: 'linear-gradient(180deg, rgba(255,255,255,0.01), transparent)',
              border: '1px solid rgba(255,255,255,0.02)'
            }}
            data-testid="feature-operations"
          >
            <div 
              className="w-[52px] h-[52px] rounded-[10px] grid place-items-center font-bold text-xl"
              style={{ background: 'rgba(255,255,255,0.03)' }}
            >
              📝
            </div>
            <div>
              <div className="font-bold">Daily Operations</div>
              <div className="text-muted text-[13px] mt-1.5">Streamline daily tasks, fill out forms and run department check ups.</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
