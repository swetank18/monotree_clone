export function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer 
      className="border-t mt-20 pt-12 pb-15"
      style={{ borderTop: '1px solid rgba(255,255,255,0.03)' }}
      data-testid="footer"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr_1fr_1fr] gap-8" data-testid="footer-grid">
          <div data-testid="footer-brand-section">
            <div className="flex gap-3 items-start mb-5" data-testid="footer-brand">
              <div 
                className="w-11 h-11 rounded-[12px] inline-grid place-items-center font-extrabold text-white shadow-cta relative overflow-hidden"
                style={{
                  background: 'linear-gradient(135deg, #10b981 0%, #059669 50%, #047857 100%)',
                  boxShadow: '0 8px 25px rgba(16, 185, 129, 0.4), inset 0 1px 0 rgba(255,255,255,0.2)',
                  border: '1px solid rgba(255,255,255,0.1)'
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/20 to-transparent" />
                <span className="relative z-10 text-sm">🌱</span>
              </div>
              <div>
                <div className="text-[15px] font-bold">Monotree</div>
                <div className="text-[12px] text-muted mt-0.5">Put people first</div>
              </div>
            </div>
            <p className="text-muted max-w-[300px]" data-testid="footer-description">
              The mobile-first platform that keeps hourly teams connected, engaged, and productive.
            </p>
          </div>
          
          <div data-testid="footer-product-section">
            <h4 className="m-0 mb-4 font-bold">Product</h4>
            <div className="space-y-2">
              <button 
                onClick={() => scrollToSection('ai-features')}
                className="block text-muted transition-smooth hover:text-foreground text-left"
                data-testid="footer-link-ai-assistant"
              >
                AI Assistant
              </button>
              <button 
                onClick={() => scrollToSection('product')}
                className="block text-muted transition-smooth hover:text-foreground text-left"
                data-testid="footer-link-features"
              >
                Features
              </button>
              <button 
                onClick={() => scrollToSection('testimonials')}
                className="block text-muted transition-smooth hover:text-foreground text-left"
                data-testid="footer-link-case-studies"
              >
                Case Studies
              </button>
              <button 
                onClick={() => scrollToSection('demo')}
                className="block text-muted transition-smooth hover:text-foreground text-left"
                data-testid="footer-link-pricing"
              >
                Pricing
              </button>
            </div>
          </div>
          
          <div data-testid="footer-company-section">
            <h4 className="m-0 mb-4 font-bold">Company</h4>
            <div className="space-y-2">
              <a href="#about" className="block text-muted transition-smooth hover:text-foreground" data-testid="footer-link-about">About</a>
              <a href="#careers" className="block text-muted transition-smooth hover:text-foreground" data-testid="footer-link-careers">Careers</a>
              <a href="#blog" className="block text-muted transition-smooth hover:text-foreground" data-testid="footer-link-blog">Blog</a>
              <a href="#contact" className="block text-muted transition-smooth hover:text-foreground" data-testid="footer-link-contact">Contact</a>
            </div>
          </div>
          
          <div data-testid="footer-support-section">
            <h4 className="m-0 mb-4 font-bold">Support</h4>
            <div className="space-y-2">
              <a href="#help" className="block text-muted transition-smooth hover:text-foreground" data-testid="footer-link-help">Help Center</a>
              <a href="#privacy" className="block text-muted transition-smooth hover:text-foreground" data-testid="footer-link-privacy">Privacy Policy</a>
              <a href="#terms" className="block text-muted transition-smooth hover:text-foreground" data-testid="footer-link-terms">Terms of Service</a>
              <a href="#security" className="block text-muted transition-smooth hover:text-foreground" data-testid="footer-link-security">Security</a>
            </div>
          </div>
        </div>
        
        <div 
          className="text-muted mt-6 pt-6"
          style={{ borderTop: '1px solid rgba(255,255,255,0.03)' }}
          data-testid="footer-legal"
        >
          <p>© 2024 Monotree. All rights reserved. Built with ❤️ for teams that put people first.</p>
        </div>
      </div>
    </footer>
  );
}
