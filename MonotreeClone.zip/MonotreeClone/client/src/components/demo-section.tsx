import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface DemoFormData {
  name: string;
  email: string;
  company: string;
  employees: string;
}

export function DemoSection() {
  const { toast } = useToast();
  const [formData, setFormData] = useState<DemoFormData>({
    name: '',
    email: '',
    company: '',
    employees: '1-50'
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const submitDemoMutation = useMutation({
    mutationFn: async (data: DemoFormData) => {
      const response = await apiRequest('POST', '/api/demo', data);
      return response.json();
    },
    onSuccess: () => {
      setIsSubmitted(true);
      toast({
        title: "Demo request submitted!",
        description: "We will contact you within a couple of hours.",
      });
    },
    onError: (error) => {
      console.error('Demo submission error:', error);
      toast({
        title: "Submission failed",
        description: "Please try again or contact us directly.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    submitDemoMutation.mutate(formData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (isSubmitted) {
    return (
      <section id="demo" className="py-20 text-center" data-testid="demo-section">
        <div className="container">
          <div className="max-w-md mx-auto bg-gradient-card rounded-[14px] p-8 border-glass" data-testid="success-message">
            <div className="text-5xl mb-4">✅</div>
            <h3 className="m-0 mb-3 text-accent font-bold">Thank you!</h3>
            <p className="text-muted m-0">We will contact you within a couple of hours.</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="demo" className="py-20 text-center" data-testid="demo-section">
      <div className="container">
        <h2 className="text-[32px] font-extrabold m-0 mb-4 text-center" data-testid="demo-section-title">
          Get your app in a few days
        </h2>
        <p className="text-muted m-0 mb-12 text-lg text-center" data-testid="demo-section-subtitle">
          We love demonstrating our platform. Let's get in touch!
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_400px] gap-12 items-center mt-12" data-testid="demo-grid">
          <div className="text-left" data-testid="demo-content">
            <h2 className="text-4xl font-extrabold m-0 mb-4">Ready to transform your workplace?</h2>
            <p className="text-muted text-base m-0 mb-6">
              Join hundreds of companies who trust Monotree to connect, engage, and develop their teams. Our platform works immediately with your existing content and grows with your organization.
            </p>
            <div className="text-muted">
              <div>✓ No long setup process</div>
              <div>✓ Works on any device</div>
              <div>✓ Immediate value from day one</div>
              <div>✓ Dedicated success manager</div>
            </div>
          </div>
          
          <div className="bg-gradient-card rounded-[14px] p-8 border-glass" data-testid="demo-form">
            <h3 className="m-0 mb-5 font-bold">Book a demo</h3>
            <p className="text-muted m-0 mb-6 text-sm">
              Fill in your information, and we will contact you within a couple of hours.
            </p>
            
            <form 
              onSubmit={handleSubmit}
              className={submitDemoMutation.isPending ? 'opacity-70 pointer-events-none' : ''}
              data-testid="demo-form-element"
            >
              <div className="mb-5 text-left" data-testid="form-group-name">
                <label className="block mb-1.5 font-semibold text-sm" htmlFor="name">
                  Full Name *
                </label>
                <input 
                  type="text" 
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full p-3 rounded-lg border font-inherit transition-smooth focus:outline-none focus:border-accent focus:shadow-[0_0_0_3px_rgba(110,231,183,0.1)]"
                  style={{
                    border: '1px solid rgba(255,255,255,0.06)',
                    background: 'rgba(255,255,255,0.02)',
                    color: '#e6eef6'
                  }}
                  required
                  data-testid="input-name"
                />
              </div>
              
              <div className="mb-5 text-left" data-testid="form-group-email">
                <label className="block mb-1.5 font-semibold text-sm" htmlFor="email">
                  Email Address *
                </label>
                <input 
                  type="email" 
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full p-3 rounded-lg border font-inherit transition-smooth focus:outline-none focus:border-accent focus:shadow-[0_0_0_3px_rgba(110,231,183,0.1)]"
                  style={{
                    border: '1px solid rgba(255,255,255,0.06)',
                    background: 'rgba(255,255,255,0.02)',
                    color: '#e6eef6'
                  }}
                  required
                  data-testid="input-email"
                />
              </div>
              
              <div className="mb-5 text-left" data-testid="form-group-company">
                <label className="block mb-1.5 font-semibold text-sm" htmlFor="company">
                  Company Name *
                </label>
                <input 
                  type="text" 
                  id="company"
                  name="company"
                  value={formData.company}
                  onChange={handleInputChange}
                  className="w-full p-3 rounded-lg border font-inherit transition-smooth focus:outline-none focus:border-accent focus:shadow-[0_0_0_3px_rgba(110,231,183,0.1)]"
                  style={{
                    border: '1px solid rgba(255,255,255,0.06)',
                    background: 'rgba(255,255,255,0.02)',
                    color: '#e6eef6'
                  }}
                  required
                  data-testid="input-company"
                />
              </div>
              
              <div className="mb-5 text-left" data-testid="form-group-employees">
                <label className="block mb-1.5 font-semibold text-sm" htmlFor="employees">
                  Number of Employees
                </label>
                <select 
                  id="employees"
                  name="employees"
                  value={formData.employees}
                  onChange={handleInputChange}
                  className="w-full p-3 rounded-lg border font-inherit transition-smooth focus:outline-none focus:border-accent focus:shadow-[0_0_0_3px_rgba(110,231,183,0.1)]"
                  style={{
                    border: '1px solid rgba(255,255,255,0.06)',
                    background: 'rgba(255,255,255,0.02)',
                    color: '#e6eef6'
                  }}
                  data-testid="select-employees"
                >
                  <option value="1-50">1-50</option>
                  <option value="51-200">51-200</option>
                  <option value="201-500">201-500</option>
                  <option value="501-1000">501-1000</option>
                  <option value="1000+">1000+</option>
                </select>
              </div>
              
              <button 
                type="submit" 
                disabled={submitDemoMutation.isPending}
                className="w-full bg-gradient-accent p-3 rounded-[10px] text-[#06202a] font-bold border-0 transition-smooth cursor-pointer text-base hover:-translate-y-0.5 hover:shadow-cta-hover disabled:opacity-50 disabled:cursor-not-allowed"
                data-testid="button-submit-demo"
              >
                {submitDemoMutation.isPending ? 'Booking...' : 'Book demo'}
              </button>
              
              <p className="text-xs text-muted mt-3 text-center" data-testid="privacy-text">
                Your information is secure with us. Read our <a href="#" className="text-accent">Privacy policy</a> for more details.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
