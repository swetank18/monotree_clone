export function AIFeaturesSection() {
  return (
    <section id="ai-features" className="py-20 text-center" data-testid="ai-features-section">
      <div className="container">
        <h2 className="text-[32px] font-extrabold m-0 mb-4 text-center" data-testid="ai-section-title">
          AI Assistant that understands your business
        </h2>
        <p className="text-muted m-0 mb-12 text-lg text-center" data-testid="ai-section-subtitle">
          Smart, secure, and instantly valuable — no setup required
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-12" data-testid="ai-features-grid">
          <div 
            className="bg-gradient-card rounded-[14px] p-6 border-glass transition-smooth hover:-translate-y-1 hover:border-white/10 text-left"
            data-testid="ai-card-instant-value"
          >
            <div 
              className="w-12 h-12 rounded-xl mb-4 grid place-items-center text-xl text-white relative overflow-hidden"
              style={{ 
                background: 'linear-gradient(135deg, #10b981 0%, #059669 50%, #047857 100%)',
                boxShadow: '0 6px 20px rgba(16, 185, 129, 0.3)'
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/20 to-transparent" />
              <span className="relative z-10">⚡</span>
            </div>
            <h3 className="m-0 mb-3 font-bold">Instant value</h3>
            <p className="text-muted m-0">No extra setup or training needed. It works immediately with the content you've already uploaded.</p>
          </div>
          
          <div 
            className="bg-gradient-card rounded-[14px] p-6 border-glass transition-smooth hover:-translate-y-1 hover:border-white/10 text-left"
            data-testid="ai-card-smart-secure"
          >
            <div 
              className="w-12 h-12 rounded-xl mb-4 grid place-items-center text-xl text-white relative overflow-hidden"
              style={{ 
                background: 'linear-gradient(135deg, #10b981 0%, #059669 50%, #047857 100%)',
                boxShadow: '0 6px 20px rgba(16, 185, 129, 0.3)'
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/20 to-transparent" />
              <span className="relative z-10">🔒</span>
            </div>
            <h3 className="m-0 mb-3 font-bold">Smart and secure</h3>
            <p className="text-muted m-0">Delivers tailored responses based on each user's departments and groups - with strict content access controls.</p>
          </div>
          
          <div 
            className="bg-gradient-card rounded-[14px] p-6 border-glass transition-smooth hover:-translate-y-1 hover:border-white/10 text-left"
            data-testid="ai-card-deep-understanding"
          >
            <div 
              className="w-12 h-12 rounded-xl mb-4 grid place-items-center text-xl text-white relative overflow-hidden"
              style={{ 
                background: 'linear-gradient(135deg, #10b981 0%, #059669 50%, #047857 100%)',
                boxShadow: '0 6px 20px rgba(16, 185, 129, 0.3)'
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/20 to-transparent" />
              <span className="relative z-10">🧠</span>
            </div>
            <h3 className="m-0 mb-3 font-bold">Deep content understanding</h3>
            <p className="text-muted m-0">Reads all handbook and course content including PDFs, Word documents, Excel files - and even understands uploaded videos.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
