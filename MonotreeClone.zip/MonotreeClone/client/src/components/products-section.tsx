export function ProductsSection() {
  return (
    <section id="product" className="py-20" data-testid="products-section">
      <div className="container">
        <h2 className="text-[32px] font-extrabold m-0 mb-4 text-center" data-testid="products-section-title">
          Everything your team needs
        </h2>
        <p className="text-muted m-0 mb-12 text-lg text-center" data-testid="products-section-subtitle">
          Four core pillars that transform your workplace
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-9" data-testid="products-grid">
          <div 
            className="bg-gradient-card p-8 rounded-[14px] border-glass transition-smooth hover:-translate-y-1 hover:border-white/10 relative overflow-hidden"
            data-testid="product-card-communication"
          >
            <div 
              className="absolute top-0 left-0 right-0 h-1"
              style={{ background: 'linear-gradient(90deg, var(--accent), var(--accent-2))' }}
            />
            <div 
              className="w-14 h-14 rounded-xl grid place-items-center text-2xl mb-5"
              style={{ background: 'rgba(255,255,255,0.03)' }}
            >
              💬
            </div>
            <div className="font-bold mb-3 text-xl" data-testid="product-title">Communication & Social</div>
            <div className="text-muted leading-relaxed" data-testid="product-description">
              A fully functional social network fosters collaboration and fun in your workplace community. Share updates, celebrate wins, and build connections across departments.
            </div>
          </div>

          <div 
            className="bg-gradient-card p-8 rounded-[14px] border-glass transition-smooth hover:-translate-y-1 hover:border-white/10 relative overflow-hidden"
            data-testid="product-card-training"
          >
            <div 
              className="absolute top-0 left-0 right-0 h-1"
              style={{ background: 'linear-gradient(90deg, var(--accent), var(--accent-2))' }}
            />
            <div 
              className="w-14 h-14 rounded-xl grid place-items-center text-2xl mb-5"
              style={{ background: 'rgba(255,255,255,0.03)' }}
            >
              📚
            </div>
            <div className="font-bold mb-3 text-xl" data-testid="product-title">Onboarding, Information & Training</div>
            <div className="text-muted leading-relaxed" data-testid="product-description">
              Efficient, media rich and intuitive development of the people in your organization. Create structured learning paths and track progress seamlessly.
            </div>
          </div>

          <div 
            className="bg-gradient-card p-8 rounded-[14px] border-glass transition-smooth hover:-translate-y-1 hover:border-white/10 relative overflow-hidden"
            data-testid="product-card-wellbeing"
          >
            <div 
              className="absolute top-0 left-0 right-0 h-1"
              style={{ background: 'linear-gradient(90deg, var(--accent), var(--accent-2))' }}
            />
            <div 
              className="w-14 h-14 rounded-xl grid place-items-center text-2xl mb-5"
              style={{ background: 'rgba(255,255,255,0.03)' }}
            >
              💚
            </div>
            <div className="font-bold mb-3 text-xl" data-testid="product-title">Well-being & Retention</div>
            <div className="text-muted leading-relaxed" data-testid="product-description">
              Give everyone a voice, measure their well-being, and retain your talent. Regular check-ins and feedback loops keep your team engaged and happy.
            </div>
          </div>

          <div 
            className="bg-gradient-card p-8 rounded-[14px] border-glass transition-smooth hover:-translate-y-1 hover:border-white/10 relative overflow-hidden"
            data-testid="product-card-operations"
          >
            <div 
              className="absolute top-0 left-0 right-0 h-1"
              style={{ background: 'linear-gradient(90deg, var(--accent), var(--accent-2))' }}
            />
            <div 
              className="w-14 h-14 rounded-xl grid place-items-center text-2xl mb-5"
              style={{ background: 'rgba(255,255,255,0.03)' }}
            >
              📝
            </div>
            <div className="font-bold mb-3 text-xl" data-testid="product-title">Daily Operations</div>
            <div className="text-muted leading-relaxed" data-testid="product-description">
              Streamline daily tasks, fill out forms and run department check ups. Turn manual processes into efficient digital workflows that save time and reduce errors.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
