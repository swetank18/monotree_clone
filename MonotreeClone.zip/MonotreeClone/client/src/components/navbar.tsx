import { useState } from 'react';

export function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      closeMobileMenu();
    }
  };

  return (
    <header 
      className="sticky top-0 z-50 glass-effect border-b border-glass"
      style={{
        background: 'linear-gradient(180deg, rgba(8,14,22,0.6), rgba(8,14,22,0.25))',
        backdropFilter: 'blur(6px)',
        borderBottom: '1px solid rgba(255,255,255,0.03)'
      }}
    >
      <div className="container">
        <nav className="flex items-center justify-between h-[72px]" data-testid="navbar">
          <div className="flex gap-3 items-center font-bold" data-testid="brand">
            <div 
              className="w-11 h-11 rounded-[12px] inline-grid place-items-center font-extrabold text-white shadow-cta relative overflow-hidden"
              style={{
                background: 'linear-gradient(135deg, #10b981 0%, #059669 50%, #047857 100%)',
                boxShadow: '0 8px 25px rgba(16, 185, 129, 0.4), inset 0 1px 0 rgba(255,255,255,0.2)',
                border: '1px solid rgba(255,255,255,0.1)'
              }}
              aria-hidden="true"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-400/20 to-transparent" />
              <span className="relative z-10 text-sm">🌱</span>
            </div>
            <div>
              <div className="text-[15px]">Monotree</div>
              <div className="text-[12px] text-muted mt-0.5">Put people first</div>
            </div>
          </div>

          <nav aria-label="Main navigation" className="hidden lg:block">
            <ul className="flex gap-5 items-center m-0 p-0 list-none">
              <li>
                <button 
                  onClick={() => scrollToSection('product')}
                  className="font-semibold text-foreground/90 transition-smooth hover:opacity-85 hover:-translate-y-0.5"
                  data-testid="nav-product"
                >
                  Product
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('ai-features')}
                  className="font-semibold text-foreground/90 transition-smooth hover:opacity-85 hover:-translate-y-0.5"
                  data-testid="nav-ai-features"
                >
                  AI Assistant
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('testimonials')}
                  className="font-semibold text-foreground/90 transition-smooth hover:opacity-85 hover:-translate-y-0.5"
                  data-testid="nav-testimonials"
                >
                  Cases
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('demo')}
                  className="font-semibold text-foreground/90 transition-smooth hover:opacity-85 hover:-translate-y-0.5"
                  data-testid="nav-demo"
                >
                  Demo
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('about')}
                  className="font-semibold text-foreground/90 transition-smooth hover:opacity-85 hover:-translate-y-0.5"
                  data-testid="nav-about"
                >
                  About
                </button>
              </li>
            </ul>
          </nav>

          <div className="flex gap-3 items-center">
            <div 
              className="px-2.5 py-1.5 rounded-lg border text-sm transition-smooth hover:bg-white/10 cursor-pointer"
              style={{
                background: 'var(--glass)',
                border: '1px solid rgba(255,255,255,0.03)'
              }}
              role="button"
              aria-label="Change language"
              data-testid="language-selector"
            >
              EN
            </div>
            <button
              onClick={() => scrollToSection('demo')}
              className="bg-gradient-accent px-4 py-2.5 rounded-[10px] text-[#06202a] font-bold shadow-cta transition-smooth hover:-translate-y-0.5 hover:shadow-cta-hover"
              data-testid="cta-book-demo"
            >
              Book a demo
            </button>
            <button 
              className="lg:hidden p-2 rounded-md transition-smooth hover:bg-white/10 text-lg"
              aria-label="Open menu"
              onClick={toggleMobileMenu}
              data-testid="hamburger-menu"
            >
              ☰
            </button>
          </div>
        </nav>

        {/* Mobile menu */}
        <div 
          className={`lg:hidden transition-all duration-300 ease-in-out overflow-hidden ${
            isMobileMenuOpen ? 'max-h-[300px] opacity-100' : 'max-h-0 opacity-0'
          }`}
          style={{
            borderTop: isMobileMenuOpen ? '1px solid rgba(255,255,255,0.02)' : 'none',
            background: isMobileMenuOpen ? 'linear-gradient(180deg, rgba(0,0,0,0.25), transparent)' : 'none'
          }}
          data-testid="mobile-menu"
        >
          <div className="container py-3">
            <nav>
              <ul className="flex flex-col gap-2.5 m-0 p-0 list-none">
                <li>
                  <button 
                    onClick={() => scrollToSection('product')}
                    className="font-semibold text-foreground/90 transition-smooth hover:opacity-85"
                    data-testid="mobile-nav-product"
                  >
                    Product
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('ai-features')}
                    className="font-semibold text-foreground/90 transition-smooth hover:opacity-85"
                    data-testid="mobile-nav-ai-features"
                  >
                    AI Assistant
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('testimonials')}
                    className="font-semibold text-foreground/90 transition-smooth hover:opacity-85"
                    data-testid="mobile-nav-testimonials"
                  >
                    Cases
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('demo')}
                    className="font-semibold text-foreground/90 transition-smooth hover:opacity-85"
                    data-testid="mobile-nav-demo"
                  >
                    Demo
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('about')}
                    className="font-semibold text-foreground/90 transition-smooth hover:opacity-85"
                    data-testid="mobile-nav-about"
                  >
                    About
                  </button>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </header>
  );
}
