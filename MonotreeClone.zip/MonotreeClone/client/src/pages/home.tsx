import { Navbar } from '@/components/navbar';
import { HeroSection } from '@/components/hero-section';
import { AIFeaturesSection } from '@/components/ai-features-section';
import { TestimonialCarousel } from '@/components/testimonial-carousel';
import { ProductsSection } from '@/components/products-section';
import { DemoSection } from '@/components/demo-section';
import { Footer } from '@/components/footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-main" data-testid="home-page">
      <Navbar />
      <main>
        <HeroSection />
        <AIFeaturesSection />
        <TestimonialCarousel />
        <ProductsSection />
        <DemoSection />
      </main>
      <Footer />
    </div>
  );
}
